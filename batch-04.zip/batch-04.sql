-- ==============================
-- CREATION OF DATABASE
-- ==============================

CREATE DATABASE SoftwareManagementSystem;

USE SoftwareManagementSystem;


-- ==============================
-- CREATION OF TABLES
-- ==============================

-- 1. DEVELOPER TABLE
CREATE TABLE Developer
(
    Developer_ID INT PRIMARY KEY AUTO_INCREMENT,
    Developer_Name VARCHAR(100) NOT NULL,
    Company VARCHAR(100) NOT NULL,
    Email VARCHAR(100) UNIQUE,
    Contact_Number VARCHAR(15)
);


-- 2. CATEGORY TABLE
CREATE TABLE Category
(
    Category_ID INT PRIMARY KEY AUTO_INCREMENT,
    Category_Name VARCHAR(100) NOT NULL UNIQUE,
    Description VARCHAR(255)
);


-- 3. USER TABLE
CREATE TABLE Users
(
    User_ID INT PRIMARY KEY AUTO_INCREMENT,
    User_Name VARCHAR(100) NOT NULL,
    Email VARCHAR(100) UNIQUE,
    Phone_Number VARCHAR(15),
    Department VARCHAR(100)
);


-- 4. SOFTWARE TABLE
CREATE TABLE Software
(
    Software_ID INT PRIMARY KEY AUTO_INCREMENT,
    Software_Name VARCHAR(100) NOT NULL,
    Category_ID INT NOT NULL,
    Developer_ID INT NOT NULL,

    FOREIGN KEY (Category_ID)
        REFERENCES Category(Category_ID),

    FOREIGN KEY (Developer_ID)
        REFERENCES Developer(Developer_ID)
);


-- 5. VERSION TABLE
CREATE TABLE Version
(
    Version_ID INT PRIMARY KEY AUTO_INCREMENT,
    Version_Number VARCHAR(30) NOT NULL,
    Release_Date DATE,
    Software_ID INT NOT NULL,

    FOREIGN KEY (Software_ID)
        REFERENCES Software(Software_ID)
);


-- 6. LICENSE TABLE
CREATE TABLE License
(
    License_ID INT PRIMARY KEY AUTO_INCREMENT,
    License_Type VARCHAR(50) NOT NULL,
    Issue_Date DATE,
    Expiry_Date DATE,
    Status VARCHAR(30),
    Software_ID INT NOT NULL,

    FOREIGN KEY (Software_ID)
        REFERENCES Software(Software_ID)
);


-- 7. BUG REPORT TABLE
CREATE TABLE Bug_Report
(
    Bug_ID INT PRIMARY KEY AUTO_INCREMENT,
    Bug_Description VARCHAR(255) NOT NULL,
    Status VARCHAR(30),
    Software_ID INT NOT NULL,

    FOREIGN KEY (Software_ID)
        REFERENCES Software(Software_ID)
);


-- 8. FEEDBACK TABLE
CREATE TABLE Feedback
(
    Feedback_ID INT PRIMARY KEY AUTO_INCREMENT,
    Rating INT,
    Comments VARCHAR(255),
    Software_ID INT NOT NULL,
    User_ID INT NOT NULL,

    FOREIGN KEY (Software_ID)
        REFERENCES Software(Software_ID),

    FOREIGN KEY (User_ID)
        REFERENCES Users(User_ID),

    CHECK (Rating BETWEEN 1 AND 5)
);


-- 9. INSTALLATION TABLE
CREATE TABLE Installation
(
    Installation_ID INT PRIMARY KEY AUTO_INCREMENT,
    Software_ID INT NOT NULL,
    User_ID INT NOT NULL,
    Install_Date DATE,
    Device_Name VARCHAR(100),

    FOREIGN KEY (Software_ID)
        REFERENCES Software(Software_ID),

    FOREIGN KEY (User_ID)
        REFERENCES Users(User_ID)
);


-- 10. SUBSCRIPTION TABLE
CREATE TABLE Subscription
(
    Subscription_ID INT PRIMARY KEY AUTO_INCREMENT,
    Plan_Name VARCHAR(50) NOT NULL,
    Start_Date DATE,
    End_Date DATE,
    User_ID INT NOT NULL,

    FOREIGN KEY (User_ID)
        REFERENCES Users(User_ID)
);


-- CHECK ALL TABLES
SHOW TABLES;


-- ==============================
-- INSERTING DATA INTO THE TABLES
-- ==============================

-- 1. DEVELOPER
INSERT INTO Developer
(Developer_Name, Company, Email, Contact_Number)
VALUES
('Arjun Kumar', 'Microsoft', 'arjun.dev@microsoft.com', '9876543210'),
('Rahul Sharma', 'Google', 'rahul.dev@google.com', '9876543211'),
('David Wilson', 'Apple', 'david.dev@apple.com', '9876543212'),
('Daniel Lee', 'NVIDIA', 'daniel.dev@nvidia.com', '9876543213'),
('Michael Brown', 'Adobe', 'michael.dev@adobe.com', '9876543214');


-- 2. CATEGORY
INSERT INTO Category
(Category_Name, Description)
VALUES
('Development Tools', 'Software used for programming and software development'),
('Web Browsers', 'Software used to access and browse the internet'),
('Office Productivity', 'Software used for office and productivity tasks'),
('Design & Graphics', 'Software used for graphic design and editing'),
('Artificial Intelligence', 'Software and tools used for AI and machine learning');


-- 3. USER
INSERT INTO Users
(User_Name, Email, Phone_Number, Department)
VALUES
('Sahithi', 'sahithi@example.com', '9000000001', 'CSE'),
('Vijay', 'vijay@example.com', '9000000002', 'AIML'),
('Yamini', 'yamini@example.com', '9000000003', 'ECE'),
('Amrutha', 'amrutha@example.com', '9000000004', 'AIML'),
('Kiran', 'kiran@example.com', '9000000005', 'CSE');


-- 4. SOFTWARE
INSERT INTO Software
(Software_Name, Category_ID, Developer_ID)
VALUES
('Visual Studio Code', 1, 1),
('Google Chrome', 2, 2),
('Microsoft Excel', 3, 1),
('Adobe Photoshop', 4, 5),
('NVIDIA CUDA', 5, 4);


-- 5. VERSION
INSERT INTO Version
(Version_Number, Release_Date, Software_ID)
VALUES
('1.95', '2024-10-01', 1),
('130.0', '2024-11-01', 2),
('2024', '2024-01-15', 3),
('25.0', '2024-09-10', 4),
('12.6', '2024-02-20', 5);


-- 6. LICENSE
INSERT INTO License
(License_Type, Issue_Date, Expiry_Date, Status, Software_ID)
VALUES
('Free', '2024-01-01', '2025-12-31', 'Active', 1),
('Free', '2024-02-01', '2025-12-31', 'Active', 2),
('Commercial', '2024-03-01', '2025-03-01', 'Expired', 3),
('Subscription', '2024-04-01', '2025-04-01', 'Expired', 4),
('Free', '2024-05-01', '2026-05-01', 'Active', 5);


-- 7. BUG REPORT
INSERT INTO Bug_Report
(Bug_Description, Status, Software_ID)
VALUES
('Extension is not loading properly', 'Open', 1),
('Browser page crashes unexpectedly', 'Resolved', 2),
('Formula calculation issue', 'Open', 3),
('Image export problem', 'In Progress', 4),
('CUDA installation error', 'Resolved', 5);


-- 8. FEEDBACK
INSERT INTO Feedback
(Rating, Comments, Software_ID, User_ID)
VALUES
(5, 'Very useful for programming', 1, 1),
(4, 'Fast and easy to use', 2, 2),
(5, 'Useful for data analysis', 3, 3),
(4, 'Good editing features', 4, 4),
(3, 'Installation was difficult', 5, 5);


-- 9. INSTALLATION
INSERT INTO Installation
(Software_ID, User_ID, Install_Date, Device_Name)
VALUES
(1, 1, '2024-09-01', 'Laptop-01'),
(1, 2, '2024-09-05', 'Laptop-02'),
(2, 1, '2024-09-10', 'Laptop-01'),
(3, 3, '2024-09-15', 'Laptop-03'),
(4, 4, '2024-09-20', 'Laptop-04');


-- 10. SUBSCRIPTION
INSERT INTO Subscription
(Plan_Name, Start_Date, End_Date, User_ID)
VALUES
('Free Plan', '2024-01-01', '2024-12-31', 1),
('Premium Plan', '2024-02-01', '2025-01-31', 2),
('Basic Plan', '2024-03-01', '2025-02-28', 3),
('Premium Plan', '2024-04-01', '2025-03-31', 4),
('Basic Plan', '2024-05-01', '2025-04-30', 5);


-- ==============================
--  DISPLAYING THE TABLES
-- ==============================

SELECT * FROM Developer;
SELECT * FROM Category;
SELECT * FROM Users;
SELECT * FROM Software;
SELECT * FROM Version;
SELECT * FROM License;
SELECT * FROM Bug_Report;
SELECT * FROM Feedback;
SELECT * FROM Installation;
SELECT * FROM Subscription;


-- ==============================
--  DML OPERATIONS
-- ==============================

-- INSERT
-- Scenario: Add a new software to the system
INSERT INTO Software
(Software_Name, Category_ID, Developer_ID)
VALUES
('Microsoft PowerPoint', 3, 1);


-- UPDATE
-- Scenario: Automatically mark licenses as expired
-- when their expiry date has passed
UPDATE License
SET Status = 'Expired'
WHERE Expiry_Date < CURRENT_DATE;
SELECT License_ID,Status,Expiry_Date FROM License;

-- updating phone number of the user
UPDATE Users
SET Phone_Number = NULL
WHERE User_ID = 5;


-- DELETE
-- Scenario: Remove a resolved bug report from the system
DELETE FROM Bug_Report
WHERE Bug_ID = 5
AND Status = 'Resolved';
SELECT * FROM Bug_Report;
-- ==============================
--  BASIC SQL QUERIES
-- ==============================

-- SELECT
-- Scenario: Display software details based on a requirement
SELECT Software_ID, Software_Name, Category_ID, Developer_ID
FROM Software;


-- DISTINCT
-- Scenario: Find the different departments of users
SELECT DISTINCT Department
FROM Users;


-- WHERE
-- Scenario: Find software belonging to the Development Tools category
SELECT *
FROM Software
WHERE Category_ID = 1;


-- finding licenses that are expired
SELECT *
FROM License
WHERE Status = 'Expired';


-- Scenario: Find subscriptions expiring within the next 30 days
SELECT *
FROM Subscription
WHERE End_Date <= CURRENT_DATE + INTERVAL 30 DAY;


-- BETWEEN
-- Scenario: Find software versions released between two dates
SELECT *
FROM Version
WHERE Release_Date BETWEEN '2024-01-01' AND '2024-12-31';


-- IN
-- Scenario: Find software belonging to selected categories
SELECT *
FROM Software
WHERE Category_ID IN (1, 3, 5);


-- NOT IN
-- Scenario: Find software that has not received any feedback
SELECT Software_ID,
       Software_Name
FROM Software
WHERE Software_ID NOT IN
(
    SELECT Software_ID
    FROM Feedback
);

-- Find users who have not installed any software
SELECT User_ID,
       User_Name
FROM Users
WHERE User_ID NOT IN
(
    SELECT User_ID
    FROM Installation
);


-- LIKE
-- Scenario: Search software using a company/product keyword
SELECT Software_ID,
       Software_Name
FROM Software
WHERE Software_Name LIKE '%Microsoft%';


-- ORDER BY
-- Scenario: Display software names in alphabetical order
SELECT Software_ID, Software_Name
FROM Software
ORDER BY Software_Name ASC;


-- latest versions sorted by release date
SELECT *
FROM Version
ORDER BY Release_Date DESC;

-- ==============================
--  LOGICAL & NULL OPERATORS
-- ==============================

-- AND
-- Scenario: Find expired licenses for a particular software
SELECT * 
FROM License
WHERE Status = 'Expired'
AND Software_ID = 3;


-- OR
-- Scenario: Find users from CSE or AIML departments
SELECT *
FROM Users
WHERE Department = 'CSE'
OR Department = 'AIML';


-- IS NULL
-- Scenario: Find users whose phone number is not provided
SELECT *
FROM Users
WHERE Phone_Number IS NULL;


-- IS NOT NULL
-- Scenario: Find users who have provided their phone number
SELECT *
FROM Users
WHERE Phone_Number IS NOT NULL;


-- ==============================
--  JOINS
-- ==============================

-- bug reports with software name
SELECT b.Bug_ID,
       s.Software_Name,
       b.Status
FROM Bug_Report b
JOIN Software s
ON b.Software_ID = s.Software_ID;


-- INNER JOIN
-- Scenario: Display software along with its developer details
SELECT S.Software_Name,
       D.Developer_Name,
       D.Company
FROM Software S
INNER JOIN Developer D
ON S.Developer_ID = D.Developer_ID;


-- LEFT JOIN
-- Scenario: Display all software and their installation details
SELECT S.Software_Name,
       I.Install_Date,
       I.Device_Name
FROM Software S
LEFT JOIN Installation I
ON S.Software_ID = I.Software_ID;


-- RIGHT JOIN
-- Scenario: Display all users and their installation details
SELECT U.User_Name,
       I.Install_Date,
       I.Device_Name
FROM Installation I
RIGHT JOIN Users U
ON I.User_ID = U.User_ID;


-- SELF JOIN
-- Scenario: Find different software developed by the same developer
SELECT S1.Software_Name AS Software1,
       S2.Software_Name AS Software2,
       D.Developer_Name
FROM Software S1
JOIN Software S2
ON S1.Developer_ID = S2.Developer_ID
AND S1.Software_ID < S2.Software_ID
JOIN Developer D
ON S1.Developer_ID = D.Developer_ID;


-- ==============================
--  AGGREGATE FUNCTIONS
-- ==============================

-- COUNT
-- Scenario: Find the total number of software installations
SELECT COUNT(*) AS Total_Installations
FROM Installation;


-- no. of software per developer
SELECT Developer_ID,
       COUNT(*) AS Software_Count
FROM Software
GROUP BY Developer_ID;


-- Find the number of users subscribed to each plan
SELECT Plan_Name,
       COUNT(*) AS Subscriber_Count
FROM Subscription
GROUP BY Plan_Name;


-- counts open bug report
SELECT COUNT(*) AS Open_Bugs
FROM Bug_Report
WHERE Status = 'Open';


-- SUM
-- Scenario: Find the total of all user feedback ratings
SELECT SUM(Rating) AS Total_Rating
FROM Feedback;


-- AVG
-- Scenario: Find the average rating given by users
SELECT AVG(Rating) AS Average_Rating
FROM Feedback;


-- MAX
-- Scenario: Find the highest feedback rating
SELECT MAX(Rating) AS Highest_Rating
FROM Feedback;


-- MIN
-- Scenario: Find the lowest feedback rating
SELECT MIN(Rating) AS Lowest_Rating
FROM Feedback;


-- ==============================
--  GROUP BY & HAVING
-- ==============================

-- GROUP BY
-- Scenario: Find the number of software installations for each software
SELECT Software_ID,
       COUNT(*) AS Installation_Count
FROM Installation
GROUP BY Software_ID;


-- HAVING
-- Scenario: Find software having more than one installation
SELECT Software_ID,
       COUNT(*) AS Installation_Count
FROM Installation
GROUP BY Software_ID
HAVING COUNT(*) > 1;


-- ==============================
--  SUBQUERIES
-- ==============================

-- Nested Subquery
-- Scenario: Find feedback records with rating above the overall average
SELECT *
FROM Feedback
WHERE Rating >
(
    SELECT AVG(Rating)
    FROM Feedback
);


-- Correlated Subquery
-- Scenario: Find users who have installed
-- more than one software

SELECT U.User_ID,
       U.User_Name
FROM Users U
WHERE
(
    SELECT COUNT(DISTINCT I.Software_ID)
    FROM Installation I
    WHERE I.User_ID = U.User_ID
) > 1;

-- ==============================
--  SET OPERATIONS
-- ==============================

-- UNION
-- Scenario: Combine software IDs from installations and feedback
-- without duplicate IDs
SELECT Software_ID
FROM Installation

UNION

SELECT Software_ID
FROM Feedback;


-- UNION ALL
-- Scenario: Combine software IDs from installations and feedback
-- including duplicate IDs
SELECT Software_ID
FROM Installation

UNION ALL

SELECT Software_ID
FROM Feedback;


-- ==============================
--  VIEWS
-- ==============================

-- UPDATABLE VIEW
-- Scenario: Manage CSE Department Users

CREATE VIEW CSE_Users AS
SELECT User_ID,
       User_Name,
       Email,
       Phone_Number,
       Department
FROM Users
WHERE Department = 'CSE';

SELECT * FROM CSE_Users;

-- Scenario: Update the phone number of a CSE user through the view

UPDATE CSE_Users
SET Phone_Number = '9999999999'
WHERE User_ID = 1;

SELECT * FROM CSE_Users;

-- Verify the updated data in the Users table

SELECT * FROM Users
WHERE User_ID = 1;



-- Non-updatable View
-- Scenario: Create a report showing software with developer and category
-- details
CREATE VIEW Software_Report AS
SELECT S.Software_Name,
       D.Developer_Name,
       C.Category_Name
FROM Software S
JOIN Developer D
ON S.Developer_ID = D.Developer_ID
JOIN Category C
ON S.Category_ID = C.Category_ID;

SELECT * FROM Software_Report;

-- ==============================
--  INDEXING
-- ==============================

-- CREATE INDEX
-- Scenario: Create an index to make software-name searches faster
CREATE INDEX idx_software_name
ON Software(Software_Name);

-- View existing indexes
SHOW INDEX FROM Software;

-- ==============================
--  DCL COMMANDS
-- ==============================
CREATE USER 'project_user'@'localhost'
IDENTIFIED BY 'Project@123';


-- GRANT
-- Scenario: Give a project user permission to view software details
GRANT SELECT
ON SoftwareManagementSystem.Software
TO 'project_user'@'localhost';


-- GRANT
-- Scenario: Give a project user permission to add and update software records
GRANT INSERT, UPDATE
ON SoftwareManagementSystem.Software
TO 'project_user'@'localhost';

SHOW GRANTS FOR 'project_user'@'localhost';

-- REVOKE
-- Scenario: Remove update permission from the project user
REVOKE UPDATE
ON SoftwareManagementSystem.Software
FROM 'project_user'@'localhost';

SHOW GRANTS FOR 'project_user'@'localhost';

-- REVOKE
-- Scenario: Remove insert permission from the project user
REVOKE INSERT
ON SoftwareManagementSystem.Software
FROM 'project_user'@'localhost';
